#!/bin/bash

g++ -DEVAL -static -O2 -std=c++11 -o citymapping grader.cpp citymapping.cpp
