void find_roads(int N, int Q, int A[], int B[], int W[]);
long long get_distance(int X, int Y);
