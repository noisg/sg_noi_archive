#include <iostream>
using namespace std;
char str[10];
int main(){
    cin >> str;
	cout << "Hello " << str << "!" << endl;
    return 0;
}
