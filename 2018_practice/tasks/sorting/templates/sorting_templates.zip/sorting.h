void sort_questions(int N, int Q, int A[]);
bool compare_difficulty(int X, int Y);