#include "sorting.h"

void sort_questions(int N, int Q, int A[]) {
	for (int i = 0; i < N; i++) {
		A[i] = i + 1;
	}
	return;
}
