import sys
raw_input = iter(sys.stdin.readlines()).next
N = int(raw_input())
for i in xrange(N):
    Xi, Yi = map(int, raw_input().split())
    # write code here
# write code here