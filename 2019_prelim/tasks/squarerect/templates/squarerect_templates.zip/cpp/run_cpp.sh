./squarerect
