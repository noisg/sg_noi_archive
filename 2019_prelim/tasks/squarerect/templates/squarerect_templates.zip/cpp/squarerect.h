bool am_i_square(int N, int Q);
bool inside_shape(int X, int Y);
