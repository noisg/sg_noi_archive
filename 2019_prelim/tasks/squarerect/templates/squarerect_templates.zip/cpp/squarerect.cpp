#include "squarerect.h"
#include <bits/stdc++.h>
using namespace std;

bool am_i_square(int N, int Q) {
	return inside_shape(1, 1);
}
