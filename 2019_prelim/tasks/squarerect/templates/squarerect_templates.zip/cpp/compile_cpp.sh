/usr/bin/g++ -DEVAL -std=gnu++11 -O2 -pipe -static -s -o squarerect grader.cpp squarerect.cpp
