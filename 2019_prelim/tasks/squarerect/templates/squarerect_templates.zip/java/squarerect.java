public class squarerect {
    public boolean am_i_square(int N, int Q){
        return grader.inside_shape(1, 1);
    }
}
