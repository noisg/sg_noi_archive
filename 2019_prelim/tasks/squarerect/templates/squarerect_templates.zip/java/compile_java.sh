/usr/bin/javac grader.java squarerect.java
